# [MAS TOOL](https://github.com/massgravel/Microsoft-Activation-Scripts) #
  - ![IMG_1674314482411_1674314628494](https://user-images.githubusercontent.com/82578024/231743414-b21c5a56-bd56-4cae-912e-244a9afd470f.jpg)
  - ![image](https://github.com/BsNgChiThanh/Lich-phong-kham/assets/82578024/d575f08f-29b1-4848-83b0-fb5e88dcb50c)
  - Giới thiệu: https://massgrave.dev/index.html#Activations_Summary
  - Rất hay, các bạn ạ!

## MAS TOOL chạy trực tiếp trên PowerShell [xem video](https://1drv.ms/v/s!AmvuvqBBIcK6i3OvF2c-SwlmAZ27?e=1aasX9) ##
- Bấm nút **Windows + R** rồi gõ vào **PowerShell** rồi enter
  - ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/20392a4f-4858-4dfc-89b0-dd3b3a243f90)
  - Dán vào câu lệnh: **CD C:\Windows\System32** rồi enter
- Hoặc: **Chạy Windows PowerShell** bằng quyền **Run as Administrator**
  - Dán 1 trong 3 câu lệnh sau rồi bấm enter:
    
    ```php
    irm https://raw.githubusercontent.com/BsNgChiThanh/MAS-TOOL/IMP/MAS.ps1 | iex
    ```

    ```php
    irm https://massgrave.dev/get | iex
    ```

    ```php
    irm https://get.activated.win | iex
    ```

  - OK!
  - Hãy chọn lựa theo yêu cầu của bạn!

## HOẶC TẢI VỀ RỒI KÍCH HOẠT ##
- Trang github https://github.com/massgravel/Microsoft-Activation-Scripts 
- Trang chủ: https://massgrave.dev/index.html
  - Linkdownlaod 1: [tại đây](https://raw.githubusercontent.com/massgravel/Microsoft-Activation-Scripts/f1ddb83df092478741344fc55351a65cf6eeafd8/MAS/All-In-One-Version-KL/MAS_AIO.cmd)
  - Linkdownlaod 2: [tại đây](https://git.activated.win/massgrave/Microsoft-Activation-Scripts/raw/commit/f1ddb83df092478741344fc55351a65cf6eeafd8/MAS/All-In-One-Version-KL/MAS_AIO.cmd)
  - Linkdownload 3: [tại đây](https://raw.githubusercontent.com/BsNgChiThanh/MAS-TOOL/refs/heads/IMP/MAS.cmd) 
  - MAS 2.9 link download bên dưới:

    [![image](https://github.com/user-attachments/assets/87c02968-9470-46de-accd-b6c3dcab2515)](https://raw.githubusercontent.com/BsNgChiThanh/MAS-TOOL/refs/heads/IMP/MAS_AIO%202.9.cmd)

  - MAS 2.2 link download bên dưới:

    [![image](https://github.com/user-attachments/assets/87c02968-9470-46de-accd-b6c3dcab2515)](https://raw.githubusercontent.com/BsNgChiThanh/MAS-TOOL/refs/heads/IMP/MAS_AIO%202.2.cmd)
  
- Từ trang trên chúng ta có thể download source nguồn của windows và office https://massgrave.dev/genuine-installation-media.html
- Đây là Tool hay, đảm bảo không có virus!
- Chạy tốt trên nền Windows 8.1 trở lên!

## KÍCH HOẠT OFFICE VĨNH VIỄN ##
- **Chỉ kích hoạt được office 2013 trở đi.**
- ![image](https://github.com/user-attachments/assets/bbb192db-5e05-4708-9923-1a0b10dd51a1)
- Bấm số 2.
- ![image](https://github.com/user-attachments/assets/f96da1c3-589c-4cf5-b103-5dba9eb83f26)
- Bấm số 1.
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/358895b8-76c1-4322-83c8-a7c1d6be3327)

## KÍCH HOẠT WINDOWS VĨNH VIỄN ##
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/89d2ad49-5569-4d93-9961-0350d25a117d)
- Bấm phím số 1
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/c596c52e-9108-495d-8a1b-82206cf5bd0c)
- Tại widows của tôi đã active rồi, nếu chưa quí vị bấm tiếp phiếm 1.
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/b8d325d3-ed02-4bf9-9bfb-96f18781d024)

### KIỂM TRA HẠN KÍCH HOẠT WINDOWS: ###
- Bấm phím Windows + R
- Điền vào **Run** rồi enter
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/aeb429cb-dae5-43e6-8847-1f7c024f1d0f)
- Copy và dán đoạn lệnh **CD C:\Windows\System32** rồi bấm enter
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/a412a204-25da-4d30-935c-18ab993c46d4) 
- Tiếp tục dán đoạn **slmgr/xpr** vào và đánh enter
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/a59b03ce-be83-4c35-9f68-038dbfa33afa)
- ![image](https://github.com/BsNgChiThanh/MAS-TOOL/assets/82578024/8b846979-a8fc-41b9-84ae-6cac900e75e9)
- Vậy là Windows được active vĩnh viễn!

## GHI CHÚ: ##
- Nếu chạy MAS Tools bạn thấy báo lỗi như sau:
- ![image](https://github.com/user-attachments/assets/f0a4aad3-63c5-4ef8-a87b-d83faaa7909e)
- Lúc này bạn bấm phím 1 để cập nhật phiên bản mới nhất.
- Hoặc [bấm vào đây](https://git.activated.win/massgrave/Microsoft-Activation-Scripts/raw/commit/f1ddb83df092478741344fc55351a65cf6eeafd8/MAS/All-In-One-Version-KL/MAS_AIO.cmd) hoặc [tại đây](https://raw.githubusercontent.com/massgravel/Microsoft-Activation-Scripts/f1ddb83df092478741344fc55351a65cf6eeafd8/MAS/All-In-One-Version-KL/MAS_AIO.cmd) để cập nhật phiên bản mới nhất.

#### CHÚC QUÍ VỊ THÀNH CÔNG! ####
